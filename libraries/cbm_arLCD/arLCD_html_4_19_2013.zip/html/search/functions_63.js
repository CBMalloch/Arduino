var searchData=
[
  ['calibrate',['calibrate',['../class_ez_l_c_d3.html#acc2e3497a227af06a3f8c4562bab4009',1,'EzLCD3']]],
  ['checkbox',['checkbox',['../class_ez_l_c_d3.html#a9c8159e589f154000f851df4fd38968f',1,'EzLCD3']]],
  ['choice',['choice',['../class_ez_l_c_d3.html#a7eb08b9b67415240a86587cd6997bdc3',1,'EzLCD3']]],
  ['circle',['circle',['../class_ez_l_c_d3.html#aaf787f9a423e66c48fef816d3b6151b0',1,'EzLCD3']]],
  ['cliparea',['cliparea',['../class_ez_l_c_d3.html#a3a75383415ce7934e49fab1689260f3a',1,'EzLCD3']]],
  ['clipenable',['clipenable',['../class_ez_l_c_d3.html#a08cd504eeb789ad7f67395a51496636e',1,'EzLCD3']]],
  ['cls',['cls',['../class_ez_l_c_d3.html#ad2543a1052a08791d51fe4afce27fdbf',1,'EzLCD3::cls(int id=0)'],['../class_ez_l_c_d3.html#a8ff140a3c9ecd2b7827254c948674556',1,'EzLCD3::cls(const char *color)']]],
  ['color',['color',['../class_ez_l_c_d3.html#a74d1d385f017fce9e53fd38bab25e29e',1,'EzLCD3::color(int id)'],['../class_ez_l_c_d3.html#a1224ed1363a527a899dfb67f981d74d2',1,'EzLCD3::color(uint8_t *red, uint8_t *green, uint8_t *blue)']]],
  ['colorid',['colorId',['../class_ez_l_c_d3.html#a84ac2d007b0c32aa421313d095158015',1,'EzLCD3::colorId(int id, uint8_t red, uint8_t green, uint8_t blue)'],['../class_ez_l_c_d3.html#aab8e49a4972dda9a4b323d07ba99d4d4',1,'EzLCD3::colorId(int id, uint8_t *red, uint8_t *green, uint8_t *blue)']]]
];
