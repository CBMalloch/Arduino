var searchData=
[
  ['xmax',['Xmax',['../class_ez_l_c_d3.html#a948f1f43091363b581057a79a5d44446a3465a15ec86004e1240f04ed533cd051',1,'EzLCD3']]],
  ['xtouch',['Xtouch',['../class_ez_l_c_d3.html#a948f1f43091363b581057a79a5d44446a16cc874cf1c79dca5dce7aa0172b2e87',1,'EzLCD3']]]
];
